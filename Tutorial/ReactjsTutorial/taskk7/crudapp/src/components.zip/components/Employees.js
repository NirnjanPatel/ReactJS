const Empolyees = [
  {
    id: 1,
    Name: "Nirnjan",
    Age: 20,
  },
  {
    id: 2,
    Name: "Birat",
    Age: 30,
  },
  {
    id: 3,
    Name: "Elon",
    Age: 40,
  },
];

export default Empolyees;
